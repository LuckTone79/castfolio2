import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PATCH(request: Request) {
  const user = await requireUser().catch(() => null);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();
  await prisma.user.update({
    where: { id: user.id },
    data: {
      name: body.name,
      phone: body.phone,
      company: body.company,
    },
  });

  return NextResponse.json({ ok: true });
}
