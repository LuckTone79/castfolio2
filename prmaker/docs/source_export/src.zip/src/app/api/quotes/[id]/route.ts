import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logAudit, logTimeline } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const user = await requireUser().catch(() => null);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const quote = await prisma.quote.findFirst({
    where: { id: params.id, userId: user.id },
    include: {
      project: { include: { talent: true } },
      lineItems: { include: { package: true } },
      order: true,
    },
  });
  if (!quote) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return NextResponse.json(quote);
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const user = await requireUser().catch(() => null);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();
  const { action } = body;

  const quote = await prisma.quote.findFirst({ where: { id: params.id, userId: user.id }, include: { project: { include: { talent: true } } } });
  if (!quote) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (action === "send") {
    const updated = await prisma.quote.update({
      where: { id: params.id },
      data: { status: "SENT", sentAt: new Date() },
    });
    await logAudit({ actorId: user.id, actorRole: user.role, action: "SEND_QUOTE", targetType: "Quote", targetId: quote.id });
    await logTimeline({ projectId: quote.projectId, event: "QUOTE_SENT", description: "견적서가 발송되었습니다", actorId: user.id, actorName: user.name });
    if (quote.project.talent.email) {
      await sendNotification({ userId: user.id, type: "quote_sent", title: "견적서 발송 완료", body: `${quote.project.talent.nameKo}님께 견적서가 발송되었습니다.`, link: `/dashboard/quotes/${quote.id}`, emailTo: user.email });
    }
    return NextResponse.json(updated);
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
